import PDFDocument from "pdfkit";
import type { ScanResult, Vulnerability } from "@shared/schema";

const COLORS = {
  primary: "#3B82F6",
  critical: "#EF4444",
  high: "#F97316",
  medium: "#EAB308",
  low: "#22C55E",
  info: "#3B82F6",
  text: "#1F2937",
  muted: "#6B7280",
  background: "#F3F4F6",
};

export function generatePdfReport(scanResult: ScanResult): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: "A4",
        margin: 50,
        info: {
          Title: `Vulnerability Scan Report - ${scanResult.targetUrl}`,
          Author: "VulnScan AI",
          Subject: "Security Vulnerability Assessment",
          Creator: "VulnScan AI Bug Bounty Scanner",
        },
      });

      const chunks: Buffer[] = [];
      doc.on("data", (chunk) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", reject);

      // Header
      drawHeader(doc, scanResult);

      // Executive Summary
      drawExecutiveSummary(doc, scanResult);

      // Severity Breakdown
      drawSeverityBreakdown(doc, scanResult);

      // AI Insights (if available)
      if (scanResult.aiInsights) {
        drawAIInsights(doc, scanResult.aiInsights);
      }

      // Vulnerability Details
      drawVulnerabilityDetails(doc, scanResult.vulnerabilities);

      // Footer
      drawFooter(doc);

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}

function drawHeader(doc: PDFKit.PDFDocument, scanResult: ScanResult) {
  // Logo/Title
  doc.fillColor(COLORS.primary)
    .fontSize(24)
    .font("Helvetica-Bold")
    .text("VulnScan AI", 50, 50);

  doc.fillColor(COLORS.muted)
    .fontSize(10)
    .font("Helvetica")
    .text("Bug Bounty Vulnerability Scanner", 50, 78);

  // Report Title
  doc.fillColor(COLORS.text)
    .fontSize(18)
    .font("Helvetica-Bold")
    .text("Security Vulnerability Report", 50, 120);

  // Target Info
  doc.fillColor(COLORS.muted)
    .fontSize(10)
    .font("Helvetica")
    .text(`Target: ${scanResult.targetUrl}`, 50, 150)
    .text(`Scan Date: ${new Date(scanResult.startedAt).toLocaleString()}`, 50, 165)
    .text(`Scan ID: ${scanResult.id}`, 50, 180)
    .text(`Duration: ${scanResult.scanDuration ? `${Math.round(scanResult.scanDuration / 1000)}s` : "N/A"}`, 50, 195);

  // Horizontal line
  doc.moveTo(50, 220)
    .lineTo(545, 220)
    .strokeColor(COLORS.background)
    .stroke();

  doc.y = 240;
}

function drawExecutiveSummary(doc: PDFKit.PDFDocument, scanResult: ScanResult) {
  doc.fillColor(COLORS.text)
    .fontSize(14)
    .font("Helvetica-Bold")
    .text("Executive Summary", 50, doc.y);

  doc.moveDown(0.5);

  const total = scanResult.totalVulnerabilities;
  const severity = scanResult.criticalCount > 0 ? "Critical" :
    scanResult.highCount > 0 ? "High" :
    scanResult.mediumCount > 0 ? "Medium" : "Low/None";

  doc.fillColor(COLORS.muted)
    .fontSize(10)
    .font("Helvetica")
    .text(`This scan identified ${total} potential security ${total === 1 ? "vulnerability" : "vulnerabilities"} ` +
      `across the target application. The highest severity level detected is ${severity}.`, {
      width: 495,
      align: "justify",
    });

  doc.moveDown();
}

function drawSeverityBreakdown(doc: PDFKit.PDFDocument, scanResult: ScanResult) {
  doc.fillColor(COLORS.text)
    .fontSize(14)
    .font("Helvetica-Bold")
    .text("Vulnerability Breakdown", 50, doc.y);

  doc.moveDown(0.5);

  const severities = [
    { label: "Critical", count: scanResult.criticalCount, color: COLORS.critical },
    { label: "High", count: scanResult.highCount, color: COLORS.high },
    { label: "Medium", count: scanResult.mediumCount, color: COLORS.medium },
    { label: "Low", count: scanResult.lowCount, color: COLORS.low },
    { label: "Info", count: scanResult.infoCount, color: COLORS.info },
  ];

  const startY = doc.y;
  const boxWidth = 90;
  const boxHeight = 40;
  const spacing = 10;

  severities.forEach((sev, index) => {
    const x = 50 + (boxWidth + spacing) * index;
    
    // Background box
    doc.rect(x, startY, boxWidth, boxHeight)
      .fillColor(sev.color)
      .fillOpacity(0.1)
      .fill();

    // Border
    doc.rect(x, startY, boxWidth, boxHeight)
      .strokeColor(sev.color)
      .strokeOpacity(0.5)
      .stroke();

    // Count
    doc.fillOpacity(1)
      .fillColor(sev.color)
      .fontSize(16)
      .font("Helvetica-Bold")
      .text(sev.count.toString(), x, startY + 8, {
        width: boxWidth,
        align: "center",
      });

    // Label
    doc.fillColor(COLORS.muted)
      .fontSize(8)
      .font("Helvetica")
      .text(sev.label, x, startY + 26, {
        width: boxWidth,
        align: "center",
      });
  });

  doc.y = startY + boxHeight + 20;
}

function drawAIInsights(doc: PDFKit.PDFDocument, insights: string) {
  // Check if we need a new page
  if (doc.y > 650) {
    doc.addPage();
    doc.y = 50;
  }

  doc.fillColor(COLORS.text)
    .fontSize(14)
    .font("Helvetica-Bold")
    .text("AI Security Insights", 50, doc.y);

  doc.moveDown(0.5);

  // Background box for insights
  const startY = doc.y;
  doc.rect(50, startY, 495, 100)
    .fillColor(COLORS.primary)
    .fillOpacity(0.05)
    .fill();

  doc.fillOpacity(1)
    .fillColor(COLORS.muted)
    .fontSize(9)
    .font("Helvetica")
    .text(insights.substring(0, 800) + (insights.length > 800 ? "..." : ""), 60, startY + 10, {
      width: 475,
      align: "justify",
    });

  doc.y = startY + 110;
}

function drawVulnerabilityDetails(doc: PDFKit.PDFDocument, vulnerabilities: Vulnerability[]) {
  if (vulnerabilities.length === 0) {
    doc.fillColor(COLORS.text)
      .fontSize(14)
      .font("Helvetica-Bold")
      .text("Detailed Findings", 50, doc.y);

    doc.moveDown(0.5);

    doc.fillColor(COLORS.muted)
      .fontSize(10)
      .font("Helvetica")
      .text("No vulnerabilities were detected during this scan.", 50, doc.y);
    
    return;
  }

  doc.addPage();
  doc.y = 50;

  doc.fillColor(COLORS.text)
    .fontSize(14)
    .font("Helvetica-Bold")
    .text("Detailed Findings", 50, doc.y);

  doc.moveDown();

  vulnerabilities.forEach((vuln, index) => {
    // Check if we need a new page
    if (doc.y > 680) {
      doc.addPage();
      doc.y = 50;
    }

    const severityColors: Record<string, string> = {
      critical: COLORS.critical,
      high: COLORS.high,
      medium: COLORS.medium,
      low: COLORS.low,
      info: COLORS.info,
    };

    const color = severityColors[vuln.severity] || COLORS.info;

    // Vulnerability header
    doc.fillColor(color)
      .fontSize(11)
      .font("Helvetica-Bold")
      .text(`${index + 1}. [${vuln.severity.toUpperCase()}] ${vuln.type}`, 50, doc.y);

    doc.moveDown(0.3);

    // URL
    doc.fillColor(COLORS.muted)
      .fontSize(8)
      .font("Helvetica")
      .text(`URL: ${vuln.url}`, 50, doc.y);

    if (vuln.cwe) {
      doc.text(`CWE: ${vuln.cwe}`, 350, doc.y - 10);
    }

    if (vuln.cvss) {
      doc.text(`CVSS: ${vuln.cvss.toFixed(1)}`, 450, doc.y - 10);
    }

    doc.moveDown(0.5);

    // Description
    doc.fillColor(COLORS.text)
      .fontSize(9)
      .font("Helvetica-Bold")
      .text("Description:", 50, doc.y);

    doc.fillColor(COLORS.muted)
      .font("Helvetica")
      .text(vuln.description, 50, doc.y + 12, {
        width: 495,
        align: "justify",
      });

    doc.moveDown();

    // Evidence (if available)
    if (vuln.evidence) {
      doc.fillColor(COLORS.text)
        .font("Helvetica-Bold")
        .text("Evidence:", 50, doc.y);

      doc.fillColor(COLORS.muted)
        .font("Helvetica")
        .text(vuln.evidence.substring(0, 200), 50, doc.y + 12, {
          width: 495,
        });

      doc.moveDown();
    }

    // Remediation
    doc.fillColor(COLORS.text)
      .font("Helvetica-Bold")
      .text("Remediation:", 50, doc.y);

    doc.fillColor(COLORS.muted)
      .font("Helvetica")
      .text(vuln.remediation, 50, doc.y + 12, {
        width: 495,
        align: "justify",
      });

    doc.moveDown(1.5);

    // Separator line
    if (index < vulnerabilities.length - 1) {
      doc.moveTo(50, doc.y)
        .lineTo(545, doc.y)
        .strokeColor(COLORS.background)
        .stroke();
      doc.moveDown(0.5);
    }
  });
}

function drawFooter(doc: PDFKit.PDFDocument) {
  // For simplicity, just add footer to the current page
  // PDFKit's switchToPage can be problematic with buffered output
  const currentDate = new Date().toLocaleDateString();
  
  // Add a bit of space before footer
  if (doc.y < 750) {
    doc.y = 750;
  }
  
  // Footer line
  doc.moveTo(50, 780)
    .lineTo(545, 780)
    .strokeColor(COLORS.background)
    .stroke();

  // Footer text
  doc.fillColor(COLORS.muted)
    .fontSize(8)
    .font("Helvetica")
    .text(
      `Generated by VulnScan AI | ${currentDate} | vulnscan-ai.com`,
      50,
      790,
      {
        width: 495,
        align: "center",
      }
    );
}
