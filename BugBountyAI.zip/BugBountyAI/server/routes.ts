import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { fetchAndAnalyzeUrl, parseCSVUrls } from "./scanner";
import { generatePdfReport } from "./pdf-generator";
import { isOpenAIConfigured } from "./openai";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === "text/csv" || file.originalname.endsWith(".csv")) {
      cb(null, true);
    } else {
      cb(new Error("Only CSV files are allowed"));
    }
  },
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "ok",
      aiEnabled: isOpenAIConfigured(),
    });
  });

  // Get all scans (history)
  app.get("/api/scans", async (req, res) => {
    try {
      const scans = await storage.getAllScans();
      res.json(scans);
    } catch (error) {
      console.error("Error fetching scans:", error);
      res.status(500).send("Failed to fetch scan history");
    }
  });

  // Get a specific scan
  app.get("/api/scans/:id", async (req, res) => {
    try {
      const scan = await storage.getScan(req.params.id);
      if (!scan) {
        return res.status(404).send("Scan not found");
      }
      res.json(scan);
    } catch (error) {
      console.error("Error fetching scan:", error);
      res.status(500).send("Failed to fetch scan");
    }
  });

  // Generate PDF report
  app.get("/api/scans/:id/pdf", async (req, res) => {
    try {
      const scan = await storage.getScan(req.params.id);
      if (!scan) {
        return res.status(404).send("Scan not found");
      }

      const pdfBuffer = await generatePdfReport(scan);
      
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="vulnerability-report-${scan.id}.pdf"`
      );
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Error generating PDF:", error);
      res.status(500).send("Failed to generate PDF report");
    }
  });

  // Start a new scan
  app.post("/api/scan", upload.single("file"), async (req, res) => {
    try {
      const { url, username, password } = req.body;
      const file = req.file;

      // Collect URLs to scan
      let urlsToScan: string[] = [];

      if (url) {
        try {
          new URL(url); // Validate URL
          urlsToScan.push(url);
        } catch {
          return res.status(400).send("Invalid URL provided");
        }
      }

      if (file) {
        const csvContent = file.buffer.toString("utf-8");
        const csvUrls = parseCSVUrls(csvContent);
        urlsToScan.push(...csvUrls);
      }

      if (urlsToScan.length === 0) {
        return res.status(400).send("No valid URLs provided");
      }

      // Remove duplicates
      urlsToScan = [...new Set(urlsToScan)];

      // Limit to 20 URLs per scan
      if (urlsToScan.length > 20) {
        urlsToScan = urlsToScan.slice(0, 20);
      }

      // Create scan record
      const primaryUrl = urlsToScan[0];
      const scan = await storage.createScan(
        urlsToScan.length === 1 ? primaryUrl : `${primaryUrl} (+${urlsToScan.length - 1} more)`
      );

      // Update status to scanning
      await storage.updateScan(scan.id, { status: "scanning" });

      const startTime = Date.now();

      // Scan all URLs
      let allVulnerabilities: typeof scan.vulnerabilities = [];
      let allInsights: string[] = [];

      for (const targetUrl of urlsToScan) {
        const result = await fetchAndAnalyzeUrl(targetUrl, {
          username: username || undefined,
          password: password || undefined,
        });

        // Add vulnerabilities
        for (const vuln of result.vulnerabilities) {
          const addedVuln = await storage.addVulnerability(scan.id, vuln);
          allVulnerabilities.push(addedVuln);
        }

        if (result.insights) {
          allInsights.push(result.insights);
        }
      }

      // Combine insights
      const combinedInsights = allInsights.length === 1 
        ? allInsights[0]
        : allInsights.map((insight, i) => `[Target ${i + 1}]\n${insight}`).join("\n\n");

      // Update scan with completion status
      const completedScan = await storage.updateScan(scan.id, {
        status: "completed",
        completedAt: new Date().toISOString(),
        scanDuration: Date.now() - startTime,
        aiInsights: combinedInsights || undefined,
        vulnerabilities: allVulnerabilities,
      });

      res.json(completedScan);
    } catch (error) {
      console.error("Scan error:", error);
      res.status(500).send(error instanceof Error ? error.message : "Scan failed");
    }
  });

  return httpServer;
}
