import { analyzeWebResponse, type VulnerabilityAnalysis } from "./openai";
import type { Vulnerability, SeverityLevel } from "@shared/schema";

interface ScanOptions {
  username?: string;
  password?: string;
}

interface WebResponseData {
  status: number;
  headers: Record<string, string>;
  body: string;
  formInputs: string[];
  scripts: string[];
  links: string[];
}

export async function fetchAndAnalyzeUrl(
  url: string,
  options?: ScanOptions
): Promise<{
  vulnerabilities: Omit<Vulnerability, "id">[];
  insights: string;
}> {
  try {
    // Fetch the target URL
    const responseData = await fetchUrl(url, options);
    
    // Analyze with AI
    const analysis = await analyzeWebResponse(url, responseData);

    // Convert analysis to vulnerability format
    const vulnerabilities: Omit<Vulnerability, "id">[] = analysis.vulnerabilities.map(vuln => ({
      type: vuln.type,
      severity: vuln.severity as SeverityLevel,
      url: url,
      description: vuln.description,
      evidence: vuln.evidence,
      remediation: vuln.remediation,
      cvss: vuln.cvss,
      cwe: vuln.cwe,
    }));

    return {
      vulnerabilities,
      insights: analysis.insights,
    };
  } catch (error) {
    console.error(`Error scanning ${url}:`, error);
    
    // Return a connectivity/error vulnerability
    return {
      vulnerabilities: [{
        type: "Scan Error",
        severity: "info" as SeverityLevel,
        url: url,
        description: `Unable to complete scan for this URL: ${error instanceof Error ? error.message : "Unknown error"}`,
        remediation: "Verify the URL is accessible and try again.",
      }],
      insights: `The scan could not be completed for ${url}. This may be due to network issues, the target being unreachable, or security measures blocking the scan.`,
    };
  }
}

async function fetchUrl(url: string, options?: ScanOptions): Promise<WebResponseData> {
  const headers: Record<string, string> = {
    "User-Agent": "VulnScanAI/1.0 Security Scanner",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
  };

  // Add basic auth if credentials provided
  if (options?.username && options?.password) {
    const credentials = Buffer.from(`${options.username}:${options.password}`).toString("base64");
    headers["Authorization"] = `Basic ${credentials}`;
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000); // 30 second timeout

  try {
    const response = await fetch(url, {
      method: "GET",
      headers,
      signal: controller.signal,
      redirect: "follow",
    });

    clearTimeout(timeout);

    const body = await response.text();
    
    // Parse response headers
    const responseHeaders: Record<string, string> = {};
    response.headers.forEach((value, key) => {
      responseHeaders[key.toLowerCase()] = value;
    });

    // Extract form inputs from HTML
    const formInputs = extractFormInputs(body);
    
    // Extract script sources
    const scripts = extractScripts(body);
    
    // Extract links
    const links = extractLinks(body, url);

    return {
      status: response.status,
      headers: responseHeaders,
      body,
      formInputs,
      scripts,
      links,
    };
  } catch (error) {
    clearTimeout(timeout);
    throw error;
  }
}

function extractFormInputs(html: string): string[] {
  const inputs: string[] = [];
  const inputRegex = /<input[^>]*>/gi;
  const textareaRegex = /<textarea[^>]*>/gi;
  const selectRegex = /<select[^>]*>/gi;
  
  let match;
  
  while ((match = inputRegex.exec(html)) !== null) {
    inputs.push(match[0]);
  }
  
  while ((match = textareaRegex.exec(html)) !== null) {
    inputs.push(match[0]);
  }
  
  while ((match = selectRegex.exec(html)) !== null) {
    inputs.push(match[0]);
  }
  
  return inputs;
}

function extractScripts(html: string): string[] {
  const scripts: string[] = [];
  const scriptRegex = /<script[^>]*(?:src=["']([^"']+)["'])?[^>]*>/gi;
  
  let match;
  while ((match = scriptRegex.exec(html)) !== null) {
    if (match[1]) {
      scripts.push(match[1]);
    }
  }
  
  return scripts;
}

function extractLinks(html: string, baseUrl: string): string[] {
  const links: string[] = [];
  const linkRegex = /href=["']([^"']+)["']/gi;
  
  let match;
  while ((match = linkRegex.exec(html)) !== null) {
    try {
      const link = new URL(match[1], baseUrl).href;
      if (!links.includes(link)) {
        links.push(link);
      }
    } catch {
      // Invalid URL, skip
    }
  }
  
  return links.slice(0, 50); // Limit to 50 links
}

export function parseCSVUrls(csvContent: string): string[] {
  const lines = csvContent.split(/\r?\n/);
  const urls: string[] = [];
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    
    // Handle comma-separated values
    const values = trimmed.split(",");
    
    for (const value of values) {
      const cleaned = value.trim().replace(/^["']|["']$/g, "");
      if (cleaned && isValidUrl(cleaned)) {
        urls.push(cleaned);
      }
    }
  }
  
  return [...new Set(urls)]; // Remove duplicates
}

function isValidUrl(str: string): boolean {
  try {
    const url = new URL(str);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}
