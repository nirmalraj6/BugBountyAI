import { randomUUID } from "crypto";
import type { 
  ScanResult, 
  ScanHistoryItem, 
  Vulnerability, 
  SeverityLevel 
} from "@shared/schema";

export interface IStorage {
  createScan(targetUrl: string): Promise<ScanResult>;
  updateScan(id: string, updates: Partial<ScanResult>): Promise<ScanResult | undefined>;
  getScan(id: string): Promise<ScanResult | undefined>;
  getAllScans(): Promise<ScanHistoryItem[]>;
  addVulnerability(scanId: string, vulnerability: Omit<Vulnerability, "id">): Promise<Vulnerability>;
}

export class MemStorage implements IStorage {
  private scans: Map<string, ScanResult>;

  constructor() {
    this.scans = new Map();
  }

  async createScan(targetUrl: string): Promise<ScanResult> {
    const id = randomUUID();
    const scan: ScanResult = {
      id,
      targetUrl,
      status: "pending",
      startedAt: new Date().toISOString(),
      vulnerabilities: [],
      totalVulnerabilities: 0,
      criticalCount: 0,
      highCount: 0,
      mediumCount: 0,
      lowCount: 0,
      infoCount: 0,
    };
    this.scans.set(id, scan);
    return scan;
  }

  async updateScan(id: string, updates: Partial<ScanResult>): Promise<ScanResult | undefined> {
    const scan = this.scans.get(id);
    if (!scan) return undefined;

    const updatedScan = { ...scan, ...updates };
    
    // Recalculate counts
    updatedScan.totalVulnerabilities = updatedScan.vulnerabilities.length;
    updatedScan.criticalCount = updatedScan.vulnerabilities.filter(v => v.severity === "critical").length;
    updatedScan.highCount = updatedScan.vulnerabilities.filter(v => v.severity === "high").length;
    updatedScan.mediumCount = updatedScan.vulnerabilities.filter(v => v.severity === "medium").length;
    updatedScan.lowCount = updatedScan.vulnerabilities.filter(v => v.severity === "low").length;
    updatedScan.infoCount = updatedScan.vulnerabilities.filter(v => v.severity === "info").length;

    this.scans.set(id, updatedScan);
    return updatedScan;
  }

  async getScan(id: string): Promise<ScanResult | undefined> {
    return this.scans.get(id);
  }

  async getAllScans(): Promise<ScanHistoryItem[]> {
    const scans = Array.from(this.scans.values());
    return scans
      .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())
      .map(scan => ({
        id: scan.id,
        targetUrl: scan.targetUrl,
        status: scan.status,
        startedAt: scan.startedAt,
        completedAt: scan.completedAt,
        totalVulnerabilities: scan.totalVulnerabilities,
        criticalCount: scan.criticalCount,
        highCount: scan.highCount,
      }));
  }

  async addVulnerability(scanId: string, vulnerability: Omit<Vulnerability, "id">): Promise<Vulnerability> {
    const scan = this.scans.get(scanId);
    if (!scan) throw new Error("Scan not found");

    const vulnWithId: Vulnerability = {
      ...vulnerability,
      id: randomUUID(),
    };

    scan.vulnerabilities.push(vulnWithId);
    await this.updateScan(scanId, { vulnerabilities: scan.vulnerabilities });
    
    return vulnWithId;
  }
}

export const storage = new MemStorage();
