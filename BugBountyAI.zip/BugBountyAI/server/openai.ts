import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = process.env.OPENAI_API_KEY 
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

export interface VulnerabilityAnalysis {
  vulnerabilities: Array<{
    type: string;
    severity: "critical" | "high" | "medium" | "low" | "info";
    description: string;
    evidence?: string;
    remediation: string;
    cvss?: number;
    cwe?: string;
  }>;
  insights: string;
}

export async function analyzeWebResponse(
  url: string,
  responseData: {
    status: number;
    headers: Record<string, string>;
    body: string;
    formInputs?: string[];
    scripts?: string[];
    links?: string[];
  }
): Promise<VulnerabilityAnalysis> {
  if (!openai) {
    // Return simulated analysis when no API key is available
    return simulateVulnerabilityAnalysis(url, responseData);
  }

  try {
    const prompt = `You are an expert web security researcher analyzing a web page for vulnerabilities. Analyze the following web response data and identify potential security vulnerabilities.

URL: ${url}
HTTP Status: ${responseData.status}
Headers: ${JSON.stringify(responseData.headers, null, 2)}
Body (truncated): ${responseData.body.substring(0, 5000)}
Form Inputs Found: ${responseData.formInputs?.join(", ") || "None"}
Scripts Found: ${responseData.scripts?.length || 0}
Links Found: ${responseData.links?.length || 0}

Analyze for common vulnerabilities including:
- XSS (Cross-Site Scripting)
- SQL Injection indicators
- CSRF vulnerabilities
- Security headers missing
- Information disclosure
- Insecure configurations
- Open redirects
- Sensitive data exposure

Provide your analysis in JSON format with the following structure:
{
  "vulnerabilities": [
    {
      "type": "vulnerability type",
      "severity": "critical|high|medium|low|info",
      "description": "detailed description",
      "evidence": "specific evidence from the response",
      "remediation": "how to fix this vulnerability",
      "cvss": 7.5,
      "cwe": "CWE-79"
    }
  ],
  "insights": "Overall security assessment and recommendations"
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a security expert specializing in web application vulnerability assessment. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 4096,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      return simulateVulnerabilityAnalysis(url, responseData);
    }

    const result = JSON.parse(content) as VulnerabilityAnalysis;
    return result;
  } catch (error) {
    console.error("OpenAI analysis error:", error);
    return simulateVulnerabilityAnalysis(url, responseData);
  }
}

function simulateVulnerabilityAnalysis(
  url: string,
  responseData: {
    status: number;
    headers: Record<string, string>;
    body: string;
    formInputs?: string[];
  }
): VulnerabilityAnalysis {
  const vulnerabilities: VulnerabilityAnalysis["vulnerabilities"] = [];
  
  // Check for missing security headers
  const headers = responseData.headers;
  
  if (!headers["content-security-policy"] && !headers["Content-Security-Policy"]) {
    vulnerabilities.push({
      type: "Security Misconfiguration",
      severity: "medium",
      description: "Content-Security-Policy header is missing. This header helps prevent XSS attacks by specifying valid sources of content.",
      evidence: "Header 'Content-Security-Policy' not found in response",
      remediation: "Add a Content-Security-Policy header to restrict sources of scripts, styles, and other resources.",
      cvss: 5.3,
      cwe: "CWE-16",
    });
  }

  if (!headers["x-frame-options"] && !headers["X-Frame-Options"]) {
    vulnerabilities.push({
      type: "Security Misconfiguration",
      severity: "medium",
      description: "X-Frame-Options header is missing. This makes the site vulnerable to clickjacking attacks.",
      evidence: "Header 'X-Frame-Options' not found in response",
      remediation: "Add X-Frame-Options: DENY or SAMEORIGIN header to prevent clickjacking.",
      cvss: 4.3,
      cwe: "CWE-1021",
    });
  }

  if (!headers["x-content-type-options"] && !headers["X-Content-Type-Options"]) {
    vulnerabilities.push({
      type: "Security Misconfiguration",
      severity: "low",
      description: "X-Content-Type-Options header is missing. This could allow MIME type sniffing attacks.",
      evidence: "Header 'X-Content-Type-Options' not found in response",
      remediation: "Add X-Content-Type-Options: nosniff header.",
      cvss: 3.1,
      cwe: "CWE-16",
    });
  }

  if (!headers["strict-transport-security"] && !headers["Strict-Transport-Security"]) {
    vulnerabilities.push({
      type: "Security Misconfiguration",
      severity: "medium",
      description: "Strict-Transport-Security (HSTS) header is missing. This makes the site vulnerable to protocol downgrade attacks.",
      evidence: "Header 'Strict-Transport-Security' not found in response",
      remediation: "Add Strict-Transport-Security header with appropriate max-age.",
      cvss: 5.0,
      cwe: "CWE-319",
    });
  }

  // Check for potential XSS in form inputs
  if (responseData.formInputs && responseData.formInputs.length > 0) {
    const hasUnprotectedInputs = responseData.formInputs.some(
      input => !input.includes("autocomplete") || input.includes("autocomplete=\"off\"")
    );
    if (hasUnprotectedInputs) {
      vulnerabilities.push({
        type: "XSS",
        severity: "high",
        description: "Form inputs detected that may be vulnerable to Cross-Site Scripting (XSS) attacks. User input should be properly validated and sanitized.",
        evidence: `Form inputs found: ${responseData.formInputs.slice(0, 3).join(", ")}`,
        remediation: "Implement input validation, output encoding, and Content Security Policy to prevent XSS attacks.",
        cvss: 6.1,
        cwe: "CWE-79",
      });
    }
  }

  // Check for information disclosure
  const body = responseData.body.toLowerCase();
  if (body.includes("error") && (body.includes("stack trace") || body.includes("exception"))) {
    vulnerabilities.push({
      type: "Information Disclosure",
      severity: "medium",
      description: "Error messages or stack traces are being exposed to users, potentially revealing sensitive implementation details.",
      evidence: "Error/exception information found in response body",
      remediation: "Implement custom error pages and avoid exposing detailed error messages in production.",
      cvss: 5.3,
      cwe: "CWE-209",
    });
  }

  // Check for potential SQL injection points
  if (url.includes("?") && (url.includes("id=") || url.includes("user=") || url.includes("page="))) {
    vulnerabilities.push({
      type: "SQL Injection",
      severity: "high",
      description: "URL contains query parameters that may be vulnerable to SQL injection attacks. Parameter-based queries should use prepared statements.",
      evidence: `Query parameters found in URL: ${url}`,
      remediation: "Use parameterized queries or prepared statements. Never concatenate user input directly into SQL queries.",
      cvss: 8.6,
      cwe: "CWE-89",
    });
  }

  // Check for cookies without secure flags
  const setCookie = headers["set-cookie"] || headers["Set-Cookie"];
  if (setCookie && (!setCookie.includes("Secure") || !setCookie.includes("HttpOnly"))) {
    vulnerabilities.push({
      type: "Sensitive Data Exposure",
      severity: "medium",
      description: "Cookies are being set without proper security flags (Secure, HttpOnly).",
      evidence: "Set-Cookie header missing Secure and/or HttpOnly flags",
      remediation: "Add Secure and HttpOnly flags to all cookies containing sensitive data.",
      cvss: 5.4,
      cwe: "CWE-614",
    });
  }

  const insights = generateInsights(vulnerabilities, url);

  return {
    vulnerabilities,
    insights,
  };
}

function generateInsights(
  vulnerabilities: VulnerabilityAnalysis["vulnerabilities"],
  url: string
): string {
  if (vulnerabilities.length === 0) {
    return `The scan of ${url} did not detect any obvious vulnerabilities. However, this does not guarantee the application is completely secure. Consider performing manual penetration testing and code review for a comprehensive security assessment.`;
  }

  const criticalHigh = vulnerabilities.filter(v => v.severity === "critical" || v.severity === "high").length;
  const medium = vulnerabilities.filter(v => v.severity === "medium").length;
  const lowInfo = vulnerabilities.filter(v => v.severity === "low" || v.severity === "info").length;

  let assessment = `Security Assessment for ${url}:\n\n`;
  
  if (criticalHigh > 0) {
    assessment += `IMMEDIATE ACTION REQUIRED: Found ${criticalHigh} critical/high severity issue(s) that require immediate attention. `;
  }
  
  assessment += `Total of ${vulnerabilities.length} potential vulnerabilities detected:\n`;
  assessment += `- ${criticalHigh} Critical/High severity\n`;
  assessment += `- ${medium} Medium severity\n`;
  assessment += `- ${lowInfo} Low/Info severity\n\n`;

  assessment += `Priority Recommendations:\n`;
  
  if (vulnerabilities.some(v => v.type === "XSS")) {
    assessment += `1. Address XSS vulnerabilities by implementing input validation, output encoding, and Content Security Policy.\n`;
  }
  if (vulnerabilities.some(v => v.type === "SQL Injection")) {
    assessment += `2. Fix potential SQL injection points by using parameterized queries.\n`;
  }
  if (vulnerabilities.some(v => v.type === "Security Misconfiguration")) {
    assessment += `3. Configure security headers (CSP, HSTS, X-Frame-Options) to strengthen the application's defense.\n`;
  }

  assessment += `\nNote: This automated scan provides a starting point for security assessment. Manual testing is recommended for comprehensive coverage.`;

  return assessment;
}

export function isOpenAIConfigured(): boolean {
  return !!openai;
}
