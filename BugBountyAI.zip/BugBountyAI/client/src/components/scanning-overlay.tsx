import { Shield, Loader2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface ScanningOverlayProps {
  isScanning: boolean;
  progress?: number;
  currentTarget?: string;
}

export function ScanningOverlay({ 
  isScanning, 
  progress = 0, 
  currentTarget 
}: ScanningOverlayProps) {
  if (!isScanning) return null;

  return (
    <Card 
      className="border-primary/30 bg-primary/5 animate-pulse-glow"
      data-testid="card-scanning-overlay"
    >
      <CardContent className="py-8">
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="relative">
            <Shield className="h-16 w-16 text-primary animate-pulse" />
            <Loader2 className="h-6 w-6 text-primary absolute -bottom-1 -right-1 animate-spin" />
          </div>
          
          <div className="space-y-2">
            <h3 className="text-lg font-semibold">Scanning for Vulnerabilities</h3>
            <p className="text-sm text-muted-foreground max-w-md">
              AI-powered analysis in progress. This may take several minutes depending on the target complexity.
            </p>
          </div>

          {currentTarget && (
            <p className="font-mono text-xs text-muted-foreground bg-muted/50 px-3 py-1.5 rounded-md">
              {currentTarget}
            </p>
          )}

          <div className="w-full max-w-xs space-y-2">
            <Progress value={progress} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {progress > 0 ? `${progress}% complete` : "Initializing scan..."}
            </p>
          </div>

          <div className="flex items-center gap-6 text-xs text-muted-foreground pt-2">
            <ScanPhase 
              label="Reconnaissance" 
              active={progress < 25} 
              complete={progress >= 25} 
            />
            <ScanPhase 
              label="Analysis" 
              active={progress >= 25 && progress < 60} 
              complete={progress >= 60} 
            />
            <ScanPhase 
              label="AI Review" 
              active={progress >= 60 && progress < 90} 
              complete={progress >= 90} 
            />
            <ScanPhase 
              label="Report" 
              active={progress >= 90} 
              complete={progress === 100} 
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ScanPhase({ 
  label, 
  active, 
  complete 
}: { 
  label: string; 
  active: boolean; 
  complete: boolean;
}) {
  return (
    <div className={cn(
      "flex items-center gap-1.5 transition-colors",
      active && "text-primary font-medium",
      complete && "text-green-500",
      !active && !complete && "opacity-50"
    )}>
      <div className={cn(
        "w-2 h-2 rounded-full",
        active && "bg-primary animate-pulse",
        complete && "bg-green-500",
        !active && !complete && "bg-muted-foreground/30"
      )} />
      {label}
    </div>
  );
}
