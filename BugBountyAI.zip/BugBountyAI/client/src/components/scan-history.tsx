import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { 
  History, 
  ExternalLink, 
  Clock,
  AlertTriangle,
  CheckCircle,
  Loader2,
  XCircle
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import type { ScanHistoryItem, ScanStatus } from "@shared/schema";

interface ScanHistoryProps {
  onSelectScan: (scanId: string) => void;
  selectedScanId?: string;
}

const statusConfig: Record<ScanStatus, { 
  icon: typeof CheckCircle; 
  className: string;
  label: string;
}> = {
  completed: {
    icon: CheckCircle,
    className: "text-green-500",
    label: "Completed",
  },
  scanning: {
    icon: Loader2,
    className: "text-blue-500 animate-spin",
    label: "Scanning",
  },
  pending: {
    icon: Clock,
    className: "text-yellow-500",
    label: "Pending",
  },
  failed: {
    icon: XCircle,
    className: "text-red-500",
    label: "Failed",
  },
};

export function ScanHistory({ onSelectScan, selectedScanId }: ScanHistoryProps) {
  const { data: scans, isLoading } = useQuery<ScanHistoryItem[]>({
    queryKey: ["/api/scans"],
  });

  if (isLoading) {
    return (
      <Card className="border-card-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <History className="h-4 w-4" />
            Scan History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-2/3" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!scans || scans.length === 0) {
    return (
      <Card className="border-card-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <History className="h-4 w-4" />
            Scan History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-4">
            No scans yet. Start your first scan above.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-card-border" data-testid="card-scan-history">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <History className="h-4 w-4" />
          Scan History
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          <div className="space-y-1 p-4 pt-0">
            {scans.map((scan) => {
              const StatusIcon = statusConfig[scan.status].icon;
              const isSelected = selectedScanId === scan.id;

              return (
                <Button
                  key={scan.id}
                  variant="ghost"
                  className={cn(
                    "w-full justify-start h-auto py-3 px-3",
                    isSelected && "bg-accent"
                  )}
                  onClick={() => onSelectScan(scan.id)}
                  data-testid={`button-history-scan-${scan.id}`}
                >
                  <div className="flex-1 text-left min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <StatusIcon 
                        className={cn("h-3.5 w-3.5", statusConfig[scan.status].className)} 
                      />
                      <span className="font-mono text-xs truncate flex-1">
                        {scan.targetUrl}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {formatDistanceToNow(new Date(scan.startedAt), { addSuffix: true })}
                      {scan.totalVulnerabilities > 0 && (
                        <>
                          <span className="text-border">|</span>
                          <span className="flex items-center gap-1">
                            <AlertTriangle className="h-3 w-3 text-yellow-500" />
                            {scan.totalVulnerabilities}
                          </span>
                        </>
                      )}
                      {scan.criticalCount > 0 && (
                        <Badge 
                          variant="outline" 
                          className="severity-critical text-xs px-1.5 py-0"
                        >
                          {scan.criticalCount} Critical
                        </Badge>
                      )}
                    </div>
                  </div>
                  <ExternalLink className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                </Button>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
