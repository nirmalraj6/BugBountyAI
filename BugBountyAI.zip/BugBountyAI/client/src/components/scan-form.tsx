import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { 
  Globe, 
  Upload, 
  User, 
  Lock, 
  Play, 
  FileText,
  X,
  Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ScanResult } from "@shared/schema";

const scanFormSchema = z.object({
  url: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
  username: z.string().optional(),
  password: z.string().optional(),
});

type ScanFormValues = z.infer<typeof scanFormSchema>;

interface ScanFormProps {
  onScanComplete: (result: ScanResult) => void;
  onScanStart: () => void;
}

export function ScanForm({ onScanComplete, onScanStart }: ScanFormProps) {
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [showAuth, setShowAuth] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const form = useForm<ScanFormValues>({
    resolver: zodResolver(scanFormSchema),
    defaultValues: {
      url: "",
      username: "",
      password: "",
    },
  });

  const scanMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await fetch("/api/scan", {
        method: "POST",
        body: data,
      });
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || "Scan failed");
      }
      return response.json() as Promise<ScanResult>;
    },
    onSuccess: (result) => {
      onScanComplete(result);
      queryClient.invalidateQueries({ queryKey: ["/api/scans"] });
      toast({
        title: "Scan Complete",
        description: `Found ${result.totalVulnerabilities} vulnerabilities`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Scan Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === "text/csv") {
      setCsvFile(file);
    } else if (file) {
      toast({
        title: "Invalid File",
        description: "Please upload a CSV file",
        variant: "destructive",
      });
    }
  };

  const removeFile = () => {
    setCsvFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const onSubmit = (values: ScanFormValues) => {
    if (!values.url && !csvFile) {
      toast({
        title: "Missing Target",
        description: "Please provide a URL or upload a CSV file",
        variant: "destructive",
      });
      return;
    }

    onScanStart();

    const formData = new FormData();
    if (values.url) formData.append("url", values.url);
    if (csvFile) formData.append("file", csvFile);
    if (values.username) formData.append("username", values.username);
    if (values.password) formData.append("password", values.password);

    scanMutation.mutate(formData);
  };

  return (
    <Card className="border-card-border shadow-lg" data-testid="card-scan-form">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <Globe className="h-5 w-5 text-primary" />
          Quick Scan
        </CardTitle>
        <CardDescription>
          Scan a single URL or upload a list of targets for vulnerability analysis
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="url"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-muted-foreground text-sm">
                      Target URL
                    </FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          placeholder="https://example.com"
                          className="pl-10 bg-background border-input"
                          {...field}
                          data-testid="input-target-url"
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">
                  Bulk List (CSV)
                </label>
                <div className="relative">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".csv"
                    onChange={handleFileChange}
                    className="hidden"
                    data-testid="input-csv-file"
                  />
                  {csvFile ? (
                    <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-primary/10 border border-primary/30">
                      <FileText className="h-4 w-4 text-primary" />
                      <span className="flex-1 truncate text-sm">{csvFile.name}</span>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={removeFile}
                        data-testid="button-remove-file"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full justify-start gap-2"
                      onClick={() => fileInputRef.current?.click()}
                      data-testid="button-upload-csv"
                    >
                      <Upload className="h-4 w-4" />
                      Upload CSV file
                    </Button>
                  )}
                </div>
              </div>
            </div>

            <Collapsible open={showAuth} onOpenChange={setShowAuth}>
              <CollapsibleTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  className="gap-2 text-muted-foreground"
                  data-testid="button-toggle-auth"
                >
                  <Lock className="h-4 w-4" />
                  {showAuth ? "Hide" : "Show"} Authentication Options
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-lg bg-muted/30 border border-border">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-muted-foreground text-sm">
                          Username (Optional)
                        </FormLabel>
                        <FormControl>
                          <div className="relative">
                            <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            <Input
                              placeholder="Enter username"
                              className="pl-10 bg-background border-input"
                              {...field}
                              data-testid="input-username"
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-muted-foreground text-sm">
                          Password (Optional)
                        </FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            <Input
                              type="password"
                              placeholder="Enter password"
                              className="pl-10 bg-background border-input"
                              {...field}
                              data-testid="input-password"
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CollapsibleContent>
            </Collapsible>

            <div className="flex justify-center pt-2">
              <Button
                type="submit"
                size="lg"
                disabled={scanMutation.isPending}
                className="gap-2 px-8"
                data-testid="button-start-scan"
              >
                {scanMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Scanning...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4" />
                    Start Scan
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
