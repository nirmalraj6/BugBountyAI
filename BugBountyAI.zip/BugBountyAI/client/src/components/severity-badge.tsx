import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { SeverityLevel } from "@shared/schema";
import { 
  AlertTriangle, 
  AlertCircle, 
  Info, 
  ShieldAlert, 
  ShieldCheck 
} from "lucide-react";

interface SeverityBadgeProps {
  severity: SeverityLevel;
  showIcon?: boolean;
  className?: string;
}

const severityConfig: Record<SeverityLevel, { 
  label: string; 
  className: string; 
  Icon: typeof AlertTriangle 
}> = {
  critical: {
    label: "Critical",
    className: "severity-critical",
    Icon: ShieldAlert,
  },
  high: {
    label: "High",
    className: "severity-high",
    Icon: AlertTriangle,
  },
  medium: {
    label: "Medium",
    className: "severity-medium",
    Icon: AlertCircle,
  },
  low: {
    label: "Low",
    className: "severity-low",
    Icon: ShieldCheck,
  },
  info: {
    label: "Info",
    className: "severity-info",
    Icon: Info,
  },
};

export function SeverityBadge({ severity, showIcon = true, className }: SeverityBadgeProps) {
  const config = severityConfig[severity];
  const Icon = config.Icon;

  return (
    <Badge 
      variant="outline" 
      className={cn("gap-1 font-medium border", config.className, className)}
      data-testid={`badge-severity-${severity}`}
    >
      {showIcon && <Icon className="h-3 w-3" />}
      {config.label}
    </Badge>
  );
}

export function SeverityCount({ 
  severity, 
  count, 
  className 
}: { 
  severity: SeverityLevel; 
  count: number;
  className?: string;
}) {
  const config = severityConfig[severity];
  const Icon = config.Icon;

  return (
    <div 
      className={cn(
        "flex items-center gap-2 px-3 py-2 rounded-md border",
        config.className,
        className
      )}
      data-testid={`count-severity-${severity}`}
    >
      <Icon className="h-4 w-4" />
      <span className="font-bold text-lg">{count}</span>
      <span className="text-sm opacity-80">{config.label}</span>
    </div>
  );
}
