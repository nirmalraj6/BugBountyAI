import { useState } from "react";
import { 
  Download, 
  Clock, 
  Target, 
  Brain,
  ChevronDown,
  ChevronUp,
  Filter
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SeverityCount } from "./severity-badge";
import { VulnerabilityCard } from "./vulnerability-card";
import type { ScanResult, SeverityLevel } from "@shared/schema";

interface ScanResultsProps {
  result: ScanResult;
}

export function ScanResults({ result }: ScanResultsProps) {
  const [showAiInsights, setShowAiInsights] = useState(true);
  const [severityFilter, setSeverityFilter] = useState<SeverityLevel | "all">("all");

  const filteredVulnerabilities = result.vulnerabilities.filter(
    (v) => severityFilter === "all" || v.severity === severityFilter
  );

  const handleDownloadPdf = async () => {
    try {
      const response = await fetch(`/api/scans/${result.id}/pdf`);
      if (!response.ok) throw new Error("Failed to generate PDF");
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `vulnerability-report-${result.id}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error("PDF download failed:", error);
    }
  };

  const formatDuration = (ms?: number) => {
    if (!ms) return "N/A";
    const seconds = Math.floor(ms / 1000);
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    return `${minutes}m ${seconds % 60}s`;
  };

  return (
    <div className="space-y-6" data-testid="section-scan-results">
      <Card className="border-card-border shadow-lg">
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <CardTitle className="text-xl font-bold">Scan Report</CardTitle>
              <CardDescription className="flex items-center gap-4 mt-2 flex-wrap">
                <span className="flex items-center gap-1 font-mono text-xs">
                  <Target className="h-3 w-3" />
                  {result.targetUrl}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {formatDuration(result.scanDuration)}
                </span>
              </CardDescription>
            </div>
            <Button
              onClick={handleDownloadPdf}
              className="gap-2"
              data-testid="button-download-pdf"
            >
              <Download className="h-4 w-4" />
              Download PDF
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3 mb-6">
            <SeverityCount severity="critical" count={result.criticalCount} />
            <SeverityCount severity="high" count={result.highCount} />
            <SeverityCount severity="medium" count={result.mediumCount} />
            <SeverityCount severity="low" count={result.lowCount} />
            <SeverityCount severity="info" count={result.infoCount} />
          </div>

          {result.aiInsights && (
            <Collapsible open={showAiInsights} onOpenChange={setShowAiInsights}>
              <Card className="bg-primary/5 border-primary/20 mb-6">
                <CollapsibleTrigger asChild>
                  <CardHeader className="cursor-pointer py-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Brain className="h-5 w-5 text-primary" />
                        <CardTitle className="text-base font-semibold">
                          AI Security Insights
                        </CardTitle>
                        <Badge variant="secondary" className="text-xs">
                          Powered by GPT
                        </Badge>
                      </div>
                      {showAiInsights ? (
                        <ChevronUp className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                  </CardHeader>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <CardContent className="pt-0">
                    <p className="text-sm text-muted-foreground whitespace-pre-line">
                      {result.aiInsights}
                    </p>
                  </CardContent>
                </CollapsibleContent>
              </Card>
            </Collapsible>
          )}

          <div className="space-y-4">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <h3 className="font-semibold">
                Vulnerabilities ({filteredVulnerabilities.length})
              </h3>
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select
                  value={severityFilter}
                  onValueChange={(v) => setSeverityFilter(v as SeverityLevel | "all")}
                >
                  <SelectTrigger className="w-32" data-testid="select-severity-filter">
                    <SelectValue placeholder="Filter" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="info">Info</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {filteredVulnerabilities.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">
                    {result.totalVulnerabilities === 0
                      ? "No vulnerabilities found"
                      : "No vulnerabilities match the selected filter"}
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {filteredVulnerabilities.map((vuln, index) => (
                  <VulnerabilityCard 
                    key={vuln.id} 
                    vulnerability={vuln} 
                    index={index}
                  />
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
