import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Shield, Check, Target, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ScanForm } from "@/components/scan-form";
import { ScanResults } from "@/components/scan-results";
import { ScanHistory } from "@/components/scan-history";
import { ScanningOverlay } from "@/components/scanning-overlay";
import type { ScanResult } from "@shared/schema";

export default function Home() {
  const [currentResult, setCurrentResult] = useState<ScanResult | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [selectedScanId, setSelectedScanId] = useState<string | undefined>();

  const { data: selectedScan } = useQuery<ScanResult>({
    queryKey: ["/api/scans", selectedScanId],
    enabled: !!selectedScanId,
  });

  const handleScanStart = () => {
    setIsScanning(true);
    setScanProgress(0);
    setCurrentResult(null);
    setSelectedScanId(undefined);

    const progressInterval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 95) {
          clearInterval(progressInterval);
          return prev;
        }
        return prev + Math.random() * 15;
      });
    }, 500);
  };

  const handleScanComplete = (result: ScanResult) => {
    setIsScanning(false);
    setScanProgress(100);
    setCurrentResult(result);
    setSelectedScanId(result.id);
  };

  const handleSelectScan = (scanId: string) => {
    setSelectedScanId(scanId);
    setCurrentResult(null);
    setIsScanning(false);
  };

  const displayResult = selectedScan || currentResult;

  return (
    <div className="min-h-full">
      <section className="py-12 px-6 text-center" data-testid="section-hero">
        <div className="max-w-3xl mx-auto space-y-6">
          <Badge 
            variant="outline" 
            className="gap-2 py-1.5 px-4 border-green-500/30 bg-green-500/10 text-green-500"
            data-testid="badge-tagline"
          >
            <Check className="h-3.5 w-3.5" />
            Detect
            <span className="text-muted-foreground mx-1">|</span>
            <Target className="h-3.5 w-3.5" />
            Prioritize
            <span className="text-muted-foreground mx-1">|</span>
            <Shield className="h-3.5 w-3.5" />
            Mitigate
          </Badge>

          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
            Find & Fix Your{" "}
            <span className="text-gradient">Vulnerabilities</span>
            {" "}&mdash; Fast.
          </h1>

          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Run AI-powered authenticated scans on any URL or upload a target list.
            Get detailed vulnerability reports with intelligent remediation suggestions.
          </p>

          <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-primary" />
              AI-Powered Analysis
            </div>
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-primary" />
              Bug Bounty Ready
            </div>
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4 text-primary" />
              Bulk Scanning
            </div>
          </div>
        </div>
      </section>

      <section className="px-6 pb-12">
        <div className="max-w-4xl mx-auto space-y-6">
          <ScanForm 
            onScanComplete={handleScanComplete} 
            onScanStart={handleScanStart}
          />

          {isScanning && (
            <ScanningOverlay 
              isScanning={isScanning} 
              progress={scanProgress}
            />
          )}

          {displayResult && !isScanning && (
            <ScanResults result={displayResult} />
          )}
        </div>
      </section>

      <section className="px-6 pb-12">
        <div className="max-w-4xl mx-auto">
          <ScanHistory 
            onSelectScan={handleSelectScan}
            selectedScanId={selectedScanId}
          />
        </div>
      </section>
    </div>
  );
}
