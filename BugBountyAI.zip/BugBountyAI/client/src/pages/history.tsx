import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow, format } from "date-fns";
import { 
  History, 
  Search, 
  Calendar,
  Target,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Loader2,
  Clock,
  Download,
  ExternalLink
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { SeverityBadge } from "@/components/severity-badge";
import { cn } from "@/lib/utils";
import type { ScanHistoryItem, ScanStatus } from "@shared/schema";

const statusConfig: Record<ScanStatus, { 
  icon: typeof CheckCircle; 
  className: string;
  label: string;
}> = {
  completed: {
    icon: CheckCircle,
    className: "text-green-500",
    label: "Completed",
  },
  scanning: {
    icon: Loader2,
    className: "text-blue-500 animate-spin",
    label: "Scanning",
  },
  pending: {
    icon: Clock,
    className: "text-yellow-500",
    label: "Pending",
  },
  failed: {
    icon: XCircle,
    className: "text-red-500",
    label: "Failed",
  },
};

export default function HistoryPage() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: scans, isLoading } = useQuery<ScanHistoryItem[]>({
    queryKey: ["/api/scans"],
  });

  const filteredScans = scans?.filter((scan) =>
    scan.targetUrl.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const handleDownloadPdf = async (scanId: string) => {
    try {
      const response = await fetch(`/api/scans/${scanId}/pdf`);
      if (!response.ok) throw new Error("Failed to generate PDF");
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `vulnerability-report-${scanId}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error("PDF download failed:", error);
    }
  };

  return (
    <div className="p-6 space-y-6" data-testid="page-history">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <History className="h-6 w-6 text-primary" />
            Scan History
          </h1>
          <p className="text-muted-foreground mt-1">
            View and manage your past vulnerability scans
          </p>
        </div>

        <div className="relative w-full max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by URL..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-history"
          />
        </div>
      </div>

      <Card className="border-card-border">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between gap-4">
            <div>
              <CardTitle className="text-lg">All Scans</CardTitle>
              <CardDescription>
                {scans?.length || 0} total scans
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filteredScans.length === 0 ? (
            <div className="text-center py-12">
              <History className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
              <p className="text-muted-foreground">
                {scans?.length === 0 
                  ? "No scans yet. Start your first scan from the dashboard."
                  : "No scans match your search."}
              </p>
            </div>
          ) : (
            <ScrollArea className="h-[500px]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Target</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Vulnerabilities</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredScans.map((scan) => {
                    const StatusIcon = statusConfig[scan.status].icon;
                    
                    return (
                      <TableRow key={scan.id} data-testid={`row-scan-${scan.id}`}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Target className="h-4 w-4 text-muted-foreground shrink-0" />
                            <span className="font-mono text-sm truncate max-w-[200px]">
                              {scan.targetUrl}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={cn(
                              "gap-1",
                              scan.status === "completed" && "severity-low",
                              scan.status === "failed" && "severity-critical",
                              scan.status === "scanning" && "severity-info",
                              scan.status === "pending" && "severity-medium"
                            )}
                          >
                            <StatusIcon className={cn("h-3 w-3", statusConfig[scan.status].className)} />
                            {statusConfig[scan.status].label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Calendar className="h-3.5 w-3.5" />
                            {format(new Date(scan.startedAt), "MMM d, yyyy")}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold">{scan.totalVulnerabilities}</span>
                            {scan.criticalCount > 0 && (
                              <Badge variant="outline" className="severity-critical text-xs px-1.5">
                                {scan.criticalCount} Critical
                              </Badge>
                            )}
                            {scan.highCount > 0 && (
                              <Badge variant="outline" className="severity-high text-xs px-1.5">
                                {scan.highCount} High
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => window.open(scan.targetUrl, "_blank")}
                              data-testid={`button-open-${scan.id}`}
                            >
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDownloadPdf(scan.id)}
                              disabled={scan.status !== "completed"}
                              data-testid={`button-download-${scan.id}`}
                            >
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
