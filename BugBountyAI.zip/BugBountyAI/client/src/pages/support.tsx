import { 
  HelpCircle, 
  Book, 
  MessageCircle, 
  FileText,
  ChevronDown,
  ExternalLink,
  Shield,
  Zap,
  Target,
  FileDown
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "How does AI-powered vulnerability scanning work?",
    answer: "VulnScan AI uses advanced machine learning models to analyze web responses, detect patterns associated with common vulnerabilities, and provide intelligent remediation suggestions. The AI examines HTTP responses, form inputs, headers, and other indicators to identify potential security issues.",
  },
  {
    question: "What types of vulnerabilities can be detected?",
    answer: "Our scanner can detect a wide range of vulnerabilities including XSS (Cross-Site Scripting), SQL Injection, CSRF, SSRF, Open Redirects, Information Disclosure, Authentication Bypass, Security Misconfiguration, and many more common web application security issues.",
  },
  {
    question: "How do I perform a bulk scan with multiple URLs?",
    answer: "Upload a CSV file containing your target URLs. The file should have one URL per line or in a single column. The scanner will process each URL sequentially and provide a comprehensive report covering all targets.",
  },
  {
    question: "What are authenticated scans?",
    answer: "Authenticated scans allow you to provide login credentials so the scanner can access protected areas of your web application. This enables deeper testing of functionality that requires user authentication.",
  },
  {
    question: "Can I download scan reports?",
    answer: "Yes! After each scan completes, you can download a comprehensive PDF report containing all findings, severity ratings, and AI-generated remediation suggestions. Reports are professional-grade and suitable for sharing with stakeholders.",
  },
  {
    question: "Is VulnScan AI safe to use on my websites?",
    answer: "VulnScan AI is designed to be non-destructive and safe for authorized testing. However, always ensure you have proper authorization before scanning any target. The scanner may generate unusual traffic patterns that could affect performance on resource-constrained servers.",
  },
];

const resources = [
  {
    icon: Book,
    title: "Documentation",
    description: "Comprehensive guides and API reference",
    link: "#",
  },
  {
    icon: MessageCircle,
    title: "Community Forum",
    description: "Connect with other security researchers",
    link: "#",
  },
  {
    icon: FileText,
    title: "Best Practices",
    description: "Security testing guidelines and tips",
    link: "#",
  },
];

export default function SupportPage() {
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8" data-testid="page-support">
      <div className="text-center space-y-4">
        <Badge variant="outline" className="gap-2">
          <HelpCircle className="h-3.5 w-3.5" />
          Help Center
        </Badge>
        <h1 className="text-3xl font-bold">Support & Resources</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Find answers to common questions, access documentation, 
          and get the help you need to make the most of VulnScan AI.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {resources.map((resource) => (
          <Card 
            key={resource.title} 
            className="border-card-border hover-elevate cursor-pointer"
          >
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <resource.icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{resource.title}</p>
                  <p className="text-sm text-muted-foreground">
                    {resource.description}
                  </p>
                </div>
                <ExternalLink className="h-4 w-4 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HelpCircle className="h-5 w-5 text-primary" />
            Frequently Asked Questions
          </CardTitle>
          <CardDescription>
            Quick answers to common questions about VulnScan AI
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left" data-testid={`faq-trigger-${index}`}>
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>

      <Card className="border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            Quick Start Guide
          </CardTitle>
          <CardDescription>
            Get started with VulnScan AI in just a few steps
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold text-sm shrink-0">
                1
              </div>
              <div>
                <p className="font-medium">Enter Target URL</p>
                <p className="text-sm text-muted-foreground">
                  Enter a single URL in the scan form or upload a CSV file with multiple targets.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold text-sm shrink-0">
                2
              </div>
              <div>
                <p className="font-medium">Configure Options (Optional)</p>
                <p className="text-sm text-muted-foreground">
                  Add authentication credentials if you need to scan protected areas.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold text-sm shrink-0">
                3
              </div>
              <div>
                <p className="font-medium">Start Scan</p>
                <p className="text-sm text-muted-foreground">
                  Click "Start Scan" and wait for the AI-powered analysis to complete.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold text-sm shrink-0">
                4
              </div>
              <div>
                <p className="font-medium">Review & Download Report</p>
                <p className="text-sm text-muted-foreground">
                  Review findings, read AI insights, and download a PDF report.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
