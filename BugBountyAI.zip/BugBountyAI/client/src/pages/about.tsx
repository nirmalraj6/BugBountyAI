import { 
  Shield, 
  Zap, 
  Target, 
  Brain, 
  FileText, 
  Lock,
  CheckCircle
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const features = [
  {
    icon: Target,
    title: "Single & Bulk Scanning",
    description: "Scan individual URLs or upload CSV files with multiple targets for comprehensive coverage.",
  },
  {
    icon: Brain,
    title: "AI-Powered Analysis",
    description: "Leverage advanced AI to identify vulnerabilities and provide intelligent remediation suggestions.",
  },
  {
    icon: Lock,
    title: "Authenticated Scans",
    description: "Perform deeper scans with optional authentication credentials for login-protected areas.",
  },
  {
    icon: FileText,
    title: "PDF Reports",
    description: "Generate professional PDF reports with detailed findings for stakeholders and clients.",
  },
  {
    icon: Zap,
    title: "Real-time Detection",
    description: "Watch vulnerabilities appear in real-time as the scanner analyzes your targets.",
  },
  {
    icon: Shield,
    title: "Bug Bounty Ready",
    description: "Designed for ethical hackers and security researchers participating in bug bounty programs.",
  },
];

const vulnerabilityTypes = [
  "XSS (Cross-Site Scripting)",
  "SQL Injection",
  "CSRF (Cross-Site Request Forgery)",
  "SSRF (Server-Side Request Forgery)",
  "Open Redirects",
  "Information Disclosure",
  "Authentication Bypass",
  "Insecure Direct Object Reference",
  "Security Misconfiguration",
  "Sensitive Data Exposure",
];

export default function AboutPage() {
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8" data-testid="page-about">
      <div className="text-center space-y-4">
        <Badge variant="outline" className="gap-2">
          <Shield className="h-3.5 w-3.5" />
          About VulnScan AI
        </Badge>
        <h1 className="text-3xl font-bold">
          AI-Powered Web Vulnerability Scanner
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          VulnScan AI is an intelligent web security tool designed for bug bounty hunters, 
          security researchers, and developers who want to identify and fix vulnerabilities 
          in their web applications quickly and efficiently.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {features.map((feature) => (
          <Card key={feature.title} className="border-card-border">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <feature.icon className="h-5 w-5 text-primary" />
                </div>
                <CardTitle className="text-base">{feature.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription>{feature.description}</CardDescription>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-card-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Vulnerability Detection Coverage
          </CardTitle>
          <CardDescription>
            Our scanner detects a wide range of common web vulnerabilities
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {vulnerabilityTypes.map((type) => (
              <div 
                key={type}
                className="flex items-center gap-2 text-sm"
              >
                <CheckCircle className="h-4 w-4 text-green-500 shrink-0" />
                <span>{type}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="py-6">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-lg bg-primary/10 border border-primary/20">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold mb-1">Ethical Use Disclaimer</h3>
              <p className="text-sm text-muted-foreground">
                VulnScan AI is designed for authorized security testing only. 
                Always ensure you have proper authorization before scanning any target. 
                Unauthorized access to computer systems is illegal and unethical. 
                Use this tool responsibly and in accordance with applicable laws and regulations.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
