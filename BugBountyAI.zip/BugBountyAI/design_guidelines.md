# AI-Powered Bug Bounty Scanner - Design Guidelines

## Design Approach

**Selected Approach:** Design System (Utility-Focused)
**Rationale:** Security/vulnerability scanning tools prioritize efficiency, clarity, and trust. Users need to quickly understand scan results, configure settings, and export reports. The interface must convey professionalism and technical competence.

**Design System:** Custom dark-themed security dashboard inspired by Linear's clean typography and Vercel's dark aesthetic, with elements from security tools like Snyk and GitLab's vulnerability dashboards.

**Core Principles:**
- **Clarity First:** Security data must be immediately scannable
- **Trust Through Polish:** Professional aesthetic builds credibility
- **Progressive Disclosure:** Complex features revealed contextually
- **Status Transparency:** Always show scan progress and system state

---

## Typography

**Font Stack:** System UI fonts for maximum performance and native feel
```
Primary: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto
Monospace (for URLs/code): ui-monospace, Menlo, Monaco, Consolas
```

**Type Scale:**
- **Hero Heading:** 40px-48px, weight 700, tight line-height (1.1)
- **Section Headings:** 24px-28px, weight 700, letter-spacing 0.3px
- **Card Titles:** 18px-20px, weight 600
- **Body Text:** 15px-16px, weight 400, line-height 1.6
- **Labels/Meta:** 13px-14px, weight 500, muted color
- **Small/Captions:** 12px, weight 500

---

## Layout System

**Spacing Units:** Tailwind scale focusing on: `2, 4, 8, 12, 16, 20, 24, 32, 48, 64`
- Component internal padding: `p-4`, `p-6`
- Section spacing: `py-12`, `py-16`, `py-20`
- Card padding: `p-6` to `p-8`
- Form field gaps: `gap-4`

**Grid Structure:**
- **Desktop:** Sidebar (220px-240px fixed) + Main content (fluid)
- **Container Max-Width:** `max-w-4xl` for scan forms, `max-w-6xl` for reports/tables
- **Card Layout:** Single column for forms, 2-3 columns for vulnerability cards

---

## Component Library

### Navigation
- **Sidebar:** Fixed left panel, subtle gradient background, border-right separator
- **Top Header:** Sticky positioning, backdrop blur effect, auth buttons right-aligned
- **Side Links:** Icon + text, rounded hover states, active state indicator

### Cards & Containers
- **Scan Card:** Prominent center card with shadow, rounded (18px), form inputs grid
- **Vulnerability Cards:** Individual findings in bordered containers, severity badges
- **Report Section:** Expandable/collapsible section, initially hidden until scan complete

### Forms & Inputs
- **Input Fields:** Dark background (#0e1629), subtle border, focus state with accent glow
- **File Upload:** Custom styled with clear visual feedback
- **Form Grid:** 2-column on desktop (URL + File, Username + Password), stack on mobile
- **Buttons:** Primary (accent blue), Secondary (bordered), Danger (red for critical vulns)

### Data Display
- **Vulnerability List:** Severity badges (High/Red, Medium/Orange, Low/Yellow, Info/Blue)
- **Scan Progress:** Loading spinner with status text, progress percentage
- **Report Table:** Striped rows, monospace for URLs/paths, expandable details
- **Badges:** Pill-shaped with icon, colored borders matching severity

### Status & Feedback
- **Loading States:** Centered spinner with descriptive text ("Scanning 5 of 20 URLs...")
- **Error Messages:** Red text, icon prefix, positioned near relevant field
- **Success Indicators:** Green checkmarks, completion badges
- **Empty States:** Helpful illustrations/icons with guidance text

---

## Visual Treatment

**No specific colors defined** - color palette will be implemented separately.

**Shadows & Depth:**
- **Cards:** Medium shadow for elevation (`0 10px 30px rgba(0,0,0,0.35)`)
- **Hover States:** Subtle lift with increased shadow
- **Modals/Overlays:** Strong shadow for clear hierarchy

**Border Radius:**
- **Cards/Containers:** 16px-18px
- **Buttons:** 12px
- **Inputs:** 12px
- **Badges/Pills:** 999px (full round)

**Borders:**
- **Subtle Dividers:** `rgba(255,255,255,0.08)` opacity
- **Card Borders:** 1px solid
- **Focus States:** 2px outline with offset

---

## Images

**Hero Section Image:**
- **Type:** Abstract cybersecurity/technology illustration or 3D rendered security shield/lock
- **Placement:** Background gradient overlay with centered content
- **Alternative:** No large hero image - rely on gradient background with icon badge
- **Style:** Dark, modern, technical aesthetic matching overall theme

**Additional Images:**
- **About Section:** Team/office environment or security operations center
- **Feature Cards:** Icon-based (no photos) - use line icons for scan types, vulnerability categories
- **Empty State:** Simple line illustration when no scans exist

---

## Page Structure

### Main Dashboard
1. **Header:** Logo/brand, navigation links, auth buttons
2. **Hero:** Badge + headline + subheadline (centered, max-w-3xl)
3. **Scan Form Card:** Prominent, centered, two-column grid inputs
4. **Report Display:** Hidden until scan completes, then revealed with results
5. **Secondary Sections:** About, Contact, Support (single column, prose width)
6. **Footer:** Minimal, centered text with disclaimer

### Scan Results View
1. **Summary Card:** Total vulns, severity breakdown, scan duration
2. **Vulnerability Grid:** 2-column cards showing findings
3. **Detail Modal:** Click vulnerability for expanded view with code snippets
4. **Action Bar:** Export PDF, Share report, New scan buttons

### Responsive Behavior
- **Desktop (1024px+):** Sidebar visible, 2-column forms
- **Tablet (768px-1023px):** Hide sidebar, single column forms, condensed header
- **Mobile (<768px):** Stack all content, full-width cards, hamburger menu

---

## Accessibility

- **Focus Indicators:** 2px accent-colored outline with 2px offset
- **ARIA Labels:** All interactive elements and form fields
- **Keyboard Navigation:** Full keyboard support for all actions
- **Screen Reader:** Descriptive labels for scan progress and results
- **Color Contrast:** Ensure 4.5:1 minimum for all text

---

## Animations

**Minimal, purposeful animations only:**
- **Scan Progress:** Pulsing dot or rotating spinner
- **Results Reveal:** Gentle fade-in (0.3s) when report appears
- **Card Hover:** Subtle translate-y(-2px) with 0.2s transition
- **Loading States:** Skeleton screens or shimmer effect (optional)

**Avoid:** Complex scroll animations, unnecessary page transitions, distracting effects