# VulnScan AI - AI-Powered Bug Bounty Vulnerability Scanner

## Overview

VulnScan AI is a web-based vulnerability scanner designed for bug bounty hunters and security researchers. The application enables users to scan single URLs or bulk upload CSV files containing multiple targets to identify common web vulnerabilities. It leverages AI-powered analysis (OpenAI) to detect security issues and provide intelligent remediation suggestions. The system generates professional PDF reports suitable for stakeholders and clients.

**Core Capabilities:**
- Single URL and bulk CSV scanning
- AI-powered vulnerability detection and analysis
- Authenticated scanning with optional credentials
- Real-time scan progress tracking
- Professional PDF report generation
- Scan history and management

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework:** React with TypeScript using Vite as the build tool

**UI Design System:** 
- Shadcn/ui component library with Radix UI primitives
- Custom dark-themed security dashboard aesthetic
- Tailwind CSS for styling with custom color tokens
- Design approach prioritizes clarity, trust, and progressive disclosure for security data presentation

**Routing:** 
- Wouter for client-side routing (lightweight alternative to React Router)
- Key routes: Dashboard (`/`), History (`/history`), About, Contact, Support

**State Management:**
- TanStack Query (React Query) for server state and API caching
- React Hook Form with Zod validation for form management
- Local component state for UI interactions

**Key Frontend Components:**
- `ScanForm`: Handles URL input, CSV upload, and authentication credentials
- `ScanResults`: Displays vulnerability findings with AI insights and PDF export
- `ScanHistory`: Lists previous scans with filtering and selection
- `ScanningOverlay`: Real-time progress indicator during active scans
- `VulnerabilityCard`: Collapsible card displaying individual vulnerability details
- `SeverityBadge`: Color-coded severity indicators (critical, high, medium, low, info)

### Backend Architecture

**Framework:** Express.js with TypeScript running on Node.js

**Server Structure:**
- Single-file entry point (`server/index.ts`) with modular route registration
- In-memory storage implementation (`MemStorage`) for scan results and vulnerability data
- Custom middleware for request logging and JSON body parsing
- Static file serving for production builds

**API Endpoints:**
- `GET /api/health` - Health check with AI configuration status
- `GET /api/scans` - Retrieve all scan history
- `GET /api/scans/:id` - Get specific scan details
- `POST /api/scans` - Initiate single URL scan
- `POST /api/scans/bulk` - Upload CSV for bulk scanning
- `GET /api/scans/:id/pdf` - Generate and download PDF report

**Core Services:**
- `scanner.ts`: URL fetching, response analysis, and vulnerability detection
- `openai.ts`: AI-powered vulnerability analysis using OpenAI API
- `pdf-generator.ts`: PDF report generation using PDFKit
- `storage.ts`: In-memory data storage abstraction (interface allows future database integration)

**Design Patterns:**
- Repository pattern via `IStorage` interface for data persistence
- Service layer separation for scanning, AI analysis, and PDF generation
- Fallback mechanisms when OpenAI API is unavailable (simulated analysis)

### Data Models

**Schema Definition (Zod-based):**
- `Vulnerability`: Individual security finding with type, severity, URL, description, evidence, remediation, CVSS score, CWE identifier
- `ScanResult`: Complete scan outcome with target URL, status, timestamps, vulnerability list, severity counts
- `ScanHistoryItem`: Lightweight scan summary for history list

**Severity Levels:** Critical, High, Medium, Low, Info

**Vulnerability Types:** XSS, SQL Injection, CSRF, SSRF, Open Redirect, Information Disclosure, Authentication Bypass, IDOR, Security Misconfiguration, Sensitive Data Exposure, Broken Access Control, XXE, Command Injection, Path Traversal, Insecure Deserialization

**Scan States:** Pending, Scanning, Completed, Failed

### Storage Solution

**Current Implementation:** In-memory storage using JavaScript Map
- Suitable for development and demonstration
- Data persists only during application runtime
- No external database dependencies

**Design for Future Migration:**
- `IStorage` interface provides abstraction layer
- Drizzle ORM configured for PostgreSQL migration
- Schema defined in `shared/schema.ts` ready for database persistence
- Configuration present for Neon serverless PostgreSQL

### Build and Deployment

**Build Process:**
- Custom build script (`script/build.ts`) using esbuild for server bundling
- Vite for client-side bundling with optimized production builds
- Server dependencies bundled to reduce cold start times (allowlist approach)
- Output: `dist/` directory with server (`index.cjs`) and client (`public/`)

**Development Mode:**
- Vite HMR for fast client-side development
- tsx for TypeScript execution without compilation
- Replit-specific plugins for enhanced development experience

## External Dependencies

### AI Services
- **OpenAI API**: GPT-based vulnerability analysis and remediation suggestions
  - Optional: Application provides fallback simulation when API key unavailable
  - Model: Configurable (referenced as "gpt-5" placeholder in code)

### UI Component Libraries
- **Radix UI**: Headless component primitives for accessibility (Accordion, Dialog, Dropdown, Select, Tabs, Toast, etc.)
- **Shadcn/ui**: Pre-styled components built on Radix primitives
- **Lucide React**: Icon library

### Form Management
- **React Hook Form**: Form state management and validation
- **Zod**: Schema validation with TypeScript type inference
- **@hookform/resolvers**: Zod resolver integration

### HTTP and File Handling
- **Multer**: File upload middleware for CSV processing
- **Axios**: HTTP client (dependency present, may be used for external requests)

### PDF Generation
- **PDFKit**: Node.js library for creating PDF reports

### Utilities
- **date-fns**: Date formatting and manipulation
- **nanoid/uuid**: Unique identifier generation
- **clsx/tailwind-merge**: Conditional CSS class composition
- **class-variance-authority**: Type-safe variant generation for components

### Database (Configured but Not Active)
- **Drizzle ORM**: TypeScript ORM for SQL databases
- **@neondatabase/serverless**: Neon Postgres serverless driver
- **PostgreSQL**: Intended production database (not currently used)

### Development Tools
- **TypeScript**: Type safety and tooling
- **Vite**: Frontend build tool and dev server
- **esbuild**: Fast JavaScript bundler for server code
- **tsx**: TypeScript execution engine
- **Tailwind CSS**: Utility-first CSS framework
- **PostCSS/Autoprefixer**: CSS processing

### Session Management (Dependencies Present)
- **express-session**: Session middleware
- **connect-pg-simple**: PostgreSQL session store
- **memorystore**: In-memory session store
- **Passport.js**: Authentication middleware (configured but not actively used)

### Rate Limiting and Security
- **express-rate-limit**: API rate limiting middleware (dependency present)
- **cors**: Cross-Origin Resource Sharing configuration