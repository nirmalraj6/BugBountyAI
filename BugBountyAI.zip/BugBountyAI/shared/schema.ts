import { z } from "zod";

// Vulnerability severity levels
export const severityLevels = ["critical", "high", "medium", "low", "info"] as const;
export type SeverityLevel = typeof severityLevels[number];

// Vulnerability types commonly found in bug bounty
export const vulnerabilityTypes = [
  "XSS",
  "SQL Injection",
  "CSRF",
  "SSRF",
  "Open Redirect",
  "Information Disclosure",
  "Authentication Bypass",
  "Insecure Direct Object Reference",
  "Security Misconfiguration",
  "Sensitive Data Exposure",
  "Broken Access Control",
  "XML External Entity",
  "Command Injection",
  "Path Traversal",
  "Insecure Deserialization",
] as const;
export type VulnerabilityType = typeof vulnerabilityTypes[number];

// Scan status
export const scanStatuses = ["pending", "scanning", "completed", "failed"] as const;
export type ScanStatus = typeof scanStatuses[number];

// Vulnerability schema
export const vulnerabilitySchema = z.object({
  id: z.string(),
  type: z.string(),
  severity: z.enum(severityLevels),
  url: z.string(),
  description: z.string(),
  evidence: z.string().optional(),
  remediation: z.string(),
  cvss: z.number().optional(),
  cwe: z.string().optional(),
});

export type Vulnerability = z.infer<typeof vulnerabilitySchema>;

// Scan result schema
export const scanResultSchema = z.object({
  id: z.string(),
  targetUrl: z.string(),
  status: z.enum(scanStatuses),
  startedAt: z.string(),
  completedAt: z.string().optional(),
  vulnerabilities: z.array(vulnerabilitySchema),
  totalVulnerabilities: z.number(),
  criticalCount: z.number(),
  highCount: z.number(),
  mediumCount: z.number(),
  lowCount: z.number(),
  infoCount: z.number(),
  scanDuration: z.number().optional(),
  aiInsights: z.string().optional(),
});

export type ScanResult = z.infer<typeof scanResultSchema>;

// Scan request schema
export const scanRequestSchema = z.object({
  url: z.string().url().optional(),
  urls: z.array(z.string().url()).optional(),
  username: z.string().optional(),
  password: z.string().optional(),
});

export type ScanRequest = z.infer<typeof scanRequestSchema>;

// Scan history item
export const scanHistoryItemSchema = z.object({
  id: z.string(),
  targetUrl: z.string(),
  status: z.enum(scanStatuses),
  startedAt: z.string(),
  completedAt: z.string().optional(),
  totalVulnerabilities: z.number(),
  criticalCount: z.number(),
  highCount: z.number(),
});

export type ScanHistoryItem = z.infer<typeof scanHistoryItemSchema>;

// Users table (for future auth)
export const users = {
  id: "",
  username: "",
  password: "",
};

export const insertUserSchema = z.object({
  username: z.string().min(3),
  password: z.string().min(6),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = { id: string; username: string; password: string };
